//
//  HomeViewController.swift
//  TaskSysMind
//
//  Created by Anand  on 26/11/22.
//

import UIKit

final class HomeViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - Properties
    var imageTag = 1
    var sectionsData = [SectionItem]()
    private var fullScreenTransitionManager: FullScreenTransitionManager?
    
    // MARK: - Lifecycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // register custom table cell
        registerNib()
        
        // fetch list data from json
        fetchHomeListData()
        
        // add tap gesture to user image
        self.userImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTapUserImageView)))
        
        userImageView.tag = imageTag
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    func registerNib(){
        tableView.register(UINib(nibName: "SectionTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "SectionTableViewCell")
        tableView.register(UINib(nibName: "MenuTableViewCell", bundle: Bundle.main), forCellReuseIdentifier: "MenuTableViewCell")
        
        tableView.separatorStyle = .none
    }
    
    func fetchHomeListData(){
        if let path = Bundle.main.path(forResource: "HomeListItem", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let model  = try JSONDecoder().decode(ItemList.self, from: data)
                self.sectionsData = model.sectionItem!
                
                // reload table view
                self.tableView.reloadData()
            } catch {
                // handle error
            }
        }
    }
    
    @objc private func didTapUserImageView(){
        // set zoom out the user image with animation
        let fullScreenTransitionManager = FullScreenTransitionManager(anchorViewTag: imageTag)
        let fullScreenImageViewController = FullScreenImageViewController(imageName: "userImage", tag: imageTag)
        fullScreenImageViewController.modalPresentationStyle = .custom
        fullScreenImageViewController.transitioningDelegate = fullScreenTransitionManager
        present(fullScreenImageViewController, animated: true)
        self.fullScreenTransitionManager = fullScreenTransitionManager
    }
}

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionsData.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sectionsData[section].isOpened ?? true ? sectionsData[section].menuItems?.count ?? 0 : 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuTableViewCell", for: indexPath) as! MenuTableViewCell
        
        let item: MenuItem = (sectionsData[indexPath.section].menuItems?[indexPath.row])!
        cell.configureMenuOptionCell(item.title ?? "", item.count ?? 0)
        
        return cell
        
    }
    
    // Header
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableCell(withIdentifier: "SectionTableViewCell") as! SectionTableViewCell
        
        header.section = section
        header.delegate = self
        
        header.configureCell(sectionsData[section].sectionTitle ?? "", sectionsData[section].sectionCount ?? 0, _isOpened: sectionsData[section].isOpened ?? false)
        
        header.animateCell()
        
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 55.0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1.0
    }
    
}

extension HomeViewController: SectionTableViewCellDelegate {
    
    func toggleSection(_ header: SectionTableViewCell, section: Int){
        if section == 0{
            sectionsData[section].isOpened = !(sectionsData[section].isOpened ?? false)
            
            // reload table view
            tableView.reloadData()
        }
    }
}
