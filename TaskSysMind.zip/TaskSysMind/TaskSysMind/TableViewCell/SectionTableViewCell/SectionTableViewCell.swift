//
//  SectionTableViewCell.swift
//  TaskSysMind
//
//  Created by Anand  on 26/11/22.
//

import UIKit

protocol SectionTableViewCellDelegate {
    func toggleSection(_ header: SectionTableViewCell, section: Int)
}

class SectionTableViewCell: UITableViewCell {

    // MARK: - Outlets
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var arrowImageView: UIImageView!

    // MARK: - Properties
    var delegate: SectionTableViewCellDelegate?
    var section: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // add tap gesture
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(SectionTableViewCell.tapHeader(_:))))
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func animateCell(){
        UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.7, initialSpringVelocity: 1, options: .curveEaseIn, animations: {

            self.contentView.layoutIfNeeded()
        })
        
    }
    
    // MARK: - Data polulation
    func configureCell(_ title: String, _ count: Int, _isOpened: Bool) {
        titleImageView.image = UIImage.init(named: title.lowercased())
        titleLabel.text = title
        
        if count > 0{
            countLabel.text = "\(count)"
            countLabel.isHidden = false
            return
        }
        
        countLabel.isHidden = true
        
        if section == 0{
            if _isOpened{
                arrowImageView.image = #imageLiteral(resourceName: "topArrow")

            }else{
                arrowImageView.image = #imageLiteral(resourceName: "bottomArrow")
            }
        }
        else{
            arrowImageView.image = #imageLiteral(resourceName: "arrow")
        }
        
    }
    
    // MARK: - Gesture event
    @objc func tapHeader(_ gestureRecognizer: UITapGestureRecognizer) {
        guard let cell = gestureRecognizer.view as? SectionTableViewCell else { return }
        
        delegate?.toggleSection(self, section: cell.section)
    }
    
}

