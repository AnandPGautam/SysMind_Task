//
//  MenuTableViewCell.swift
//  TaskSysMind
//
//  Created by Anand  on 26/11/22.
//

import UIKit

class MenuTableViewCell: UITableViewCell {

    // MARK: - Outlets
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    // MARK: - Data polulation
    func configureMenuOptionCell(_ title: String, _ count: Int) {
        titleLabel.text = title
        countLabel.text = "\(count)"
        
        if count > 0{
            countLabel.backgroundColor = UIColor.orangeColor
            countLabel.textColor = UIColor.whiteColor
        }
    }
    
}
