//
//  Utility.swift
//  TaskSysMind
//
//  Created by Anand  on 26/11/22.
//

import Foundation
import UIKit

/*---------------------------------------------------
 MARK:- Designable classes
 ---------------------------------------------------*/

@IBDesignable
class CircleView: UIView {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.backgroundColor = UIColor.orangeColor.cgColor
        self.layer.cornerRadius = self.frame.width / 2
        self.clipsToBounds = true
    }
}

@IBDesignable
class ShadowImageView: UIImageView
{
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.shadowColor = UIColor.grayColor.cgColor
        self.layer.shadowOpacity = 0.4
        self.layer.shadowOffset = CGSize(width: 1.0, height: 2.0)
        self.layer.shadowRadius = 3.0
        self.layer.shouldRasterize = true
        self.layer.rasterizationScale = true ? UIScreen.main.scale : 1
    }
}

@IBDesignable
class SquareBtn: UIButton {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.backgroundColor = UIColor.orangeColor.cgColor
        self.layer.cornerRadius = 10
        self.clipsToBounds = true
    }
}

@IBDesignable
class SquareLabel: UILabel {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.cornerRadius = 3
        self.clipsToBounds = true
    }
}




