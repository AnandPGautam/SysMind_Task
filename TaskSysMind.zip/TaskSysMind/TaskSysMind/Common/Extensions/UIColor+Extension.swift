//
//  UIColor+Extension.swift
//  TaskSysMind
//
//  Created by Anand  on 26/11/22.
//

import UIKit

extension UIColor {
    
    static var orangeColor: UIColor {
        return UIColor(red: 243.0 / 255.0, green: 65.0 / 255.0, blue: 53.0 / 255.0, alpha: 1.0)
    }
    
    static var whiteColor: UIColor {
        return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 1.0)
    }
    
    static var grayColor: UIColor {
        return UIColor(red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, alpha: 1.0)
    }
    
    static var viewBackgroundColor: UIColor {
        return UIColor(red: 48.0 / 255.0, green: 42.0 / 255.0, blue: 42.0 / 255.0, alpha: 1.0)
    }
    
    static var cellBackgroundColor: UIColor {
        return UIColor(red: 26.0 / 255.0, green: 26.0 / 255.0, blue: 26.0 / 255.0, alpha: 1.0)
    }
    
    static var expandedCellBackgroundColor: UIColor {
        return UIColor(red: 31.0 / 255.0, green: 31.0 / 255.0, blue: 31.0 / 255.0, alpha: 1.0)
    }
    
        
}
