//
//  ItemListModel.swift
//  TaskSysMind
//
//  Created by Anand  on 26/11/22.
//

import Foundation

// MARK: - ItemListModel
struct ItemList: Codable {
    let sectionItem: [SectionItem]?

    enum CodingKeys: String, CodingKey {
        case sectionItem = "SectionItem"
    }
}

// MARK: - SectionItem
struct SectionItem: Codable {
    let sectionTitle: String?
    let sectionCount: Int?
    let menuItems: [MenuItem]?
    var isOpened: Bool?
}

// MARK: - MenuItem
struct MenuItem: Codable {
    let title: String?
    let count: Int?
}
